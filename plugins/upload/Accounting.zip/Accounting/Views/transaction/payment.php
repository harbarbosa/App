
<table id="sales-table" class="display table-sales" cellspacing="0" width="100%">            
</table>