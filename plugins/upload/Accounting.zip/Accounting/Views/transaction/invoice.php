
<table id="sales-invoices-table" class="display" cellspacing="0" width="100%">            
</table>

<?php require 'plugins/Accounting/assets/js/transaction/invoice_js.php';?>

