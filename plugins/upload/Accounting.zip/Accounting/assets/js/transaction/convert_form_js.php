
<script type="text/javascript">
    $(document).ready(function () {
        "use strict";
        $("#convert-form .select2").select2();
    });
</script>