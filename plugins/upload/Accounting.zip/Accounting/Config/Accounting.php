<?php

namespace Accounting\Config;

use CodeIgniter\Config\BaseConfig;
use Accounting\Models\Accounting_settings_model;

class Accounting extends BaseConfig {


    public function __construct() {
       
    }

}
