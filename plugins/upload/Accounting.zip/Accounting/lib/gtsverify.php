<?php
require_once __DIR__ .'/gtsslib.php';
$client_name = 'risecrm';
$lic_accounting = new AccountingLic();

  $msg = 'done! Nulled by codingshop.net';
  $status = 1;
