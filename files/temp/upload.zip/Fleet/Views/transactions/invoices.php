<div class="row general-form">
  <div class="col-md-3">
    <?php echo render_date_input('from_date','from_date'); ?>
  </div>
  <div class="col-md-3">
    <?php echo render_date_input('to_date','to_date'); ?>
  </div>
</div>
<table class="table table-fleet-invoices">
  <thead>
    <th><?php echo _l('invoice'); ?></th>
    <th><?php echo _l('date'); ?></th>
    <th><?php echo _l('amount'); ?></th>
    <th><?php echo _l('customer'); ?></th>
    <th><?php echo _l('status'); ?></th>
  </thead>
  <tbody>
    
  </tbody>
</table>