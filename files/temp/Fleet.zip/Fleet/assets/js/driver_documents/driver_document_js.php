<script>
(function($) {
  "use strict";


})(jQuery);
</script>
