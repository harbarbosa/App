<div class="row general-form">
  <div class="col-md-3">
    <?php echo render_date_input('from_date','from_date'); ?>
  </div>
  <div class="col-md-3">
    <?php echo render_date_input('to_date','to_date'); ?>
  </div>
</div>
<table class="table table-fleet-expenses">
  <thead>
    <th><?php echo _l('name'); ?></th>
    <th><?php echo _l('date'); ?></th>
    <th><?php echo _l('amount'); ?></th>
    <th><?php echo _l('category'); ?></th>
  </thead>
  <tbody>
    
  </tbody>
</table>