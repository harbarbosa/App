<?php

namespace Fleet\Config;

use CodeIgniter\Config\BaseConfig;
use Fleet\Models\Fleet_settings_model;

class Fleet extends BaseConfig {


    public function __construct() {
       
    }

}
